#include <QHBoxLayout>
#include <QVBoxLayout>
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent)
{
    QWidget *val = new QWidget(this);

    QHBoxLayout *hlayout = new QHBoxLayout(val);
	QVBoxLayout *vlayout = new QVBoxLayout;



    scene = new QGraphicsScene(0, 0, 490, 490);
	grid = new Grid;
	scene->addItem(grid);
	grid->init();
    hlayout->addWidget(view = new View(scene));
	grid->setFocus();
	hlayout->addLayout(vlayout);

    vlayout->addWidget(lScore = new QLabel(tr("Score:\n0")));
    vlayout->addWidget(NewAdventure = new QPushButton("&New Adventure"));
    vlayout->addWidget(Quit = new QPushButton("&Quit"));

    setCentralWidget(val);

    connect(grid, SIGNAL(scoreChanged(int)), this, SLOT(newscore(int)));
    connect(NewAdventure, SIGNAL(clicked()), grid, SLOT(reinit()));
    connect(Quit, SIGNAL(clicked()), qApp, SLOT(quit()));

	grid->load("2048.dat");
    NewAdventure->setStyleSheet("QPushButton { background-color: #BBADA0 ; }");
    Quit->setStyleSheet("QPushButton { background-color: #BBADA0 ; }");
}

void MainWindow::newscore(int score)
{
    lScore->setText(QString(tr(" Score:%1")).arg(score));
    lScore->setStyleSheet("QLabel { background-color : #BBADA0; color : black; }");
    QFont f( "Arial", 10);
      lScore->setFont( f);
}
