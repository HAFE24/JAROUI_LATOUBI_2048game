#ifndef CELLULE_H
#define CELLULE_H

#include <QGraphicsWidget>

class Cellule : public QGraphicsWidget
{
	Q_OBJECT
public:
    explicit Cellule(int x, int y, int v, QGraphicsItem * parent = 0, Qt::WindowFlags wFlags = 0);
    ~Cellule();
	void paint(QPainter * painter, const QStyleOptionGraphicsItem *, QWidget * = 0);
	QRectF boundingRect(void) const;
	int x(void) const {return data.x;}
	void setX(const int x) {data.x = x;}
	int y(void) const {return data.y;}
	void setY(const int y) {data.y = y;}
    int val(void) const {return data.v;}
    void setVal(const int v);
	bool merged(void) const {return data.merged;}
	void setMerged(bool merged) {data.merged = merged;}
	void refresh(void);

private:
	struct {
		bool merged;
		int x, y, v, vc;
	} data;
};

#endif // CELLULE_H
