# Qt5_2048
Game 2048 implemented using Qt5  
  
Function | Class
-------|---------------
Render | QGraphicsScene
Animation | QParallelAnimationGroup

* Images from bilibili's 2048 implement
