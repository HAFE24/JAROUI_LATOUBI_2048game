#ifndef ACTION_H
#define ACTION_H

#include <QObject>
#include <QParallelAnimationGroup>
#include <QGraphicsWidget>
#include <QList>
#include "cellule.h"

class Action : public QObject
{
    Q_OBJECT
public:
    explicit Action(const int dur, QObject *parent = 0);


    void add(QGraphicsWidget *val, QPointF to);
    void New(QGraphicsWidget *val);
    void Delete(QGraphicsWidget *val);
    void Refresh(Cellule *val);
    void purge(QGraphicsWidget *val);

signals:

public slots:
    void start(void);
    void stop(void);

private:
    void clear(void);

    int duration;
    QParallelAnimationGroup *group;
    QList<QGraphicsWidget *> news, deletes;
    QList<Cellule *> refresh;
};

#endif // ACTION_H
