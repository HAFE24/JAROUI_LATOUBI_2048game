#include <QPainter>
#include <QGraphicsScene>
#include <QFont>
#include "cellule.h"
#include "tilework.h"
#include "grid.h"

Cellule::Cellule(int x, int y, int v, QGraphicsItem *parent, Qt::WindowFlags wFlags) :
	QGraphicsWidget(parent, wFlags)
{
	setX(x);
	setY(y);
    setVal(v);
	setMerged(false);
	setCacheMode(DeviceCoordinateCache);
	refresh();
}

Cellule::~Cellule()
{
	if (scene())
		scene()->removeItem(this);
}

QRectF Cellule::boundingRect(void) const
{
	QRectF rCon(FRAME, FRAME, scene()->width() - FRAME * 2, scene()->height() - FRAME * 2);
	QRectF rCell(0, 0, (rCon.width() - FRAME * 3) / 4, (rCon.width() - FRAME * 3) / 4);
	return rCell;
}

void Cellule::setVal(const int v)
{
	data.v = v;
	setZValue(abs(v));
}

void Cellule::refresh(void)
{
	data.vc = data.v;
	update(boundingRect());
}

void Cellule::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
	QRectF rCell = boundingRect();
    painter->setPen(Tilework::background(data.vc));
    painter->setBrush(Tilework::background(data.vc));
	painter->drawRoundRect(rCell, 3, 3);
	if (data.vc == 0)
		return;
    painter->setFont(Tilework::font(data.vc));
    painter->setPen(Tilework::foreground(data.vc));
	painter->drawText(rCell, Qt::AlignCenter, QString::number(data.vc));

}
