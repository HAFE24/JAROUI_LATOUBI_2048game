#include <QPainter>
#include <QGraphicsScene>
#include <QMessageBox>
#include <QtWidgets>
#include <QPropertyAnimation>
#include <QFile>
#include <QDataStream>
#include <QTextStream>
#include <ctime>
#include "grid.h"
#include "tilework.h"

Grid::Grid(QGraphicsItem *parent, Qt::WindowFlags wFlags) :
	QGraphicsWidget(parent, wFlags)
{
	qsrand(time(NULL));
    ani = new Action(150, this);
	setZValue(-1);
	setFlag(ItemIsFocusable, true);
	setFocusPolicy(Qt::StrongFocus);
	setAcceptedMouseButtons(Qt::AllButtons);
	setCacheMode(DeviceCoordinateCache);
	connect(qApp, SIGNAL(aboutToQuit()), ani, SLOT(stop()));
}

void Grid::init(void)
{
	score = 0;
	succeed = false;
    emit scoreChanged(score);
	QRectF rCell = boundingRect().adjusted(FRAME, FRAME, -FRAME, -FRAME);
    rCell.setWidth((rCell.width() - FRAME * 3) / 4);
	rCell.setHeight((rCell.height() - FRAME * 3) / 4);
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++) {
            cells[x][y] = new Cellule(x, y, 0, this);
			cells[x][y]->setPos(rCell.left() + x * (rCell.width() + FRAME), \
					    rCell.top() + y * (rCell.height() + FRAME));
		}
	generate();
}

void Grid::reinit(void)
{
	ani->stop();
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			delete cells[x][y];
	init();
}

QRectF Grid::boundingRect(void) const
{
	return QRectF(0, 0, scene()->width(), scene()->height());
}

QPainterPath Grid::shape(void) const
{
	QPainterPath path;
	path.addRoundRect(boundingRect(), 3, 3);
	return path;
}

void Grid::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->setPen(Tilework::foreground(0));
    painter->setBrush(Tilework::foreground(0));
	painter->drawRoundRect(boundingRect(), 3, 3);

	QRectF rCell = boundingRect().adjusted(FRAME, FRAME, -FRAME, -FRAME);
	rCell.setWidth((rCell.width() - FRAME * 3) / 4);
	rCell.setHeight((rCell.height() - FRAME * 3) / 4);
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++) {
            painter->setPen(Tilework::background(0));
            painter->setBrush(Tilework::background(0));
			painter->drawRoundRect(rCell.left() + x * (rCell.width() + FRAME), \
					       rCell.top() + y * (rCell.height() + FRAME), \
					       rCell.width(), rCell.height(), 3, 3);
		}
}

bool Grid::move(const vect& dir)
{
	ani->stop();
	bool succeedBak = succeed;
	int scoreBak = score;
	bool moved = false;
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++) {
			int xt = dir.x == 1 ? 3 - x : x;
			int yt = dir.y == 1 ? 3 - y : y;
            if (cells[xt][yt]->val() == 0)
				continue;
            Cellule **cellule = find(&cells[xt][yt], dir);
            if (&cells[xt][yt] != cellule)
				moved = true;
            move(&cells[xt][yt], cellule);
        }
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
			cells[x][y]->setMerged(false);
	ani->start();
	if (score != scoreBak)
        emit scoreChanged(score);
	if (succeedBak == false && succeed == true) {
		if (QMessageBox::information((QWidget *)scene()->views().first(), \
                         "Succeed", "You got 2048\ndo you want to Continue?", \
					     QMessageBox::Yes, QMessageBox::No) == QMessageBox::No) {
			reinit();
			return false;
		}
	}
	return moved;
}

void Grid::move(Cellule **from, Cellule **to)
{
	if (*from == *to)
		return;
	QRectF rCell = boundingRect().adjusted(FRAME, FRAME, -FRAME, -FRAME);
	rCell.setWidth((rCell.width() - FRAME * 3) / 4);
	rCell.setHeight((rCell.height() - FRAME * 3) / 4);
    if ((*to)->val() != 0) {
        (*from)->setVal((*from)->val() + (*to)->val());
		(*from)->setMerged(true);
        ani->Refresh(*from);
        score += (*to)->val();
        if ((*from)->val() == 2048)
			succeed = true;
	}
	int x = (*to)->x(), y = (*to)->y();
    ani->Delete(*to);
	*to = *from;
    *from = new Cellule((*from)->x(), (*from)->y(), 0, this);
	(*from)->setPos(rCell.left() + (*to)->x() * (rCell.width() + FRAME), \
		      rCell.top() + (*to)->y() * (rCell.height() + FRAME));
	(*to)->setX(x);
	(*to)->setY(y);

	ani->add(*to, QPointF(rCell.left() + x * (rCell.width() + FRAME), \
			      rCell.top() + y * (rCell.height() + FRAME)));
}

class Cellule **Grid::find(Cellule **orig, const vect dir)
{
	int x = (*orig)->x(), y = (*orig)->y();
	do {
		x += dir.x;
		y += dir.y;
    } while (x >= 0 && x <= 3 && y >= 0 && y <= 3 && cells[x][y]->val() == 0);
	if (x >= 0 && x <= 3 && y >= 0 && y <= 3 && \
            abs(cells[x][y]->val()) == abs((*orig)->val()) && \
			!cells[x][y]->merged())
		return &cells[x][y];
	x -= dir.x;
	y -= dir.y;
	return &cells[x][y];
}

bool Grid::generate(void)
{
    QList<Cellule **> list;
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++) {
            if (cells[x][y]->val() != 0)
				continue;
			list.append(&cells[x][y]);
		}
	if (list.count() == 0)
		return false;
    Cellule **cellule = list.at(qrand() % list.count());
    (*cellule)->setVal((qrand() % 100) < 90 ? 2 : 4);
    (*cellule)->refresh();
    ani->New(*cellule);
	return true;
}

bool Grid::failed(void)
{
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++) {
            if (cells[x][y]->val() == 0)
				return false;
            if (x != 0 && abs(cells[x][y]->val()) == abs(cells[x - 1][y]->val()))
				return false;
            if (x != 3 && abs(cells[x][y]->val()) == abs(cells[x + 1][y]->val()))
				return false;
            if (y != 0 && abs(cells[x][y]->val()) == abs(cells[x][y - 1]->val()))
				return false;
            if (y != 3 && abs(cells[x][y]->val()) == abs(cells[x][y + 1]->val()))
				return false;
		}
	return true;
}

void Grid::save(QString path)
{
	QFile f(path);
	if (!f.open(f.WriteOnly)) {
		QMessageBox::critical((QWidget *)scene()->views().first(), \
				      "Error", "Cannot open file for save!");
		return;
	}
	QTextStream fs(&f);
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++)
            fs << cells[x][y]->val() << " ";
	fs << score << " " << succeed;
	f.close();
}

void Grid::load(QString path)
{
	QFile f(path);
	if (!f.open(f.ReadOnly)) {
		QMessageBox::critical((QWidget *)scene()->views().first(), \
				      "Error", "Cannot open file for load!");
		return;
	}
	QTextStream fs(&f);
	for (int x = 0; x < 4; x++)
		for (int y = 0; y < 4; y++) {
            int val;
            fs >> val;
            cells[x][y]->setVal(val);
			cells[x][y]->refresh();
		}
	int s;
	fs >> score >> s;
	succeed = s;
	f.close();
	emit scoreChanged(score);
	if (failed()) {
		QMessageBox::critical((QWidget *)scene()->views().first(), \
                       "Game over", "Oh No, it's over!");
		reinit();
	}
}

void Grid::op(const vect& dir)
{
	if (move(dir)) {
		generate();
		save("2048.dat");
		if (failed()) {
			QMessageBox::critical((QWidget *)scene()->views().first(), \
                          "Game over", "Oh No, it's over!");
			reinit();
		}
	}
}

void Grid::keyPressEvent(QKeyEvent *event)
{
	vect dir = {0, 0};
	switch (event->key()) {
	case Qt::Key_W:
	case Qt::Key_K:
	case Qt::Key_Up:
		dir.y = -1;
		break;
	case Qt::Key_S:
	case Qt::Key_J:
	case Qt::Key_Down:
		dir.y = 1;
		break;
	case Qt::Key_A:
	case Qt::Key_H:
	case Qt::Key_Left:
		dir.x = -1;
		break;
	case Qt::Key_D:
	case Qt::Key_L:
	case Qt::Key_Right:
		dir.x = 1;
		break;
	case Qt::Key_P:
		dir.x = rand() % 3 - 1;
		if (dir.x == 0)
			dir.y = rand() % 3 - 1;
		break;
	case Qt::Key_R:
		reinit();
		return;
	case Qt::Key_Q:
		qApp->quit();
		return;
	default:
		return;
	}
	op(dir);
}

void Grid::mousePressEvent(QGraphicsSceneMouseEvent *e)
{
	e->accept();
	mouse = e->pos();
}

void Grid::mouseReleaseEvent(QGraphicsSceneMouseEvent *e)
{
	e->accept();
	int x = e->pos().x() - mouse.x(), y = e->pos().y() - mouse.y();
	if (x == y)
		return;
	vect dir = {0, 0};
	if (abs(x) > abs(y))
		dir.x = x > 0 ? 1 : -1;
	else
		dir.y = y > 0 ? 1 : -1;
	op(dir);
}
