#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtWidgets>
#include "view.h"
#include "grid.h"

class MainWindow : public QMainWindow
{
	Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = 0);

signals:
private:
    QGraphicsScene *scene;
    Grid *grid;
    View *view;
    QLabel *lScore;
    QPushButton *NewAdventure, *Quit;

public slots:

private slots:
    void newscore(int score);


};

#endif // MAINWINDOW_H
