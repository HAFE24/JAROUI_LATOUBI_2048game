#include <QPropertyAnimation>
#include "action.h"

Action::Action(const int dur, QObject *parent) :
    QObject(parent), duration(dur)
{
    group = new QParallelAnimationGroup(this);
    connect(group, SIGNAL(finished()), this, SLOT(stop()));
}

void Action::start(void)
{
    group->start();
}

void Action::stop(void)
{
    if (group->state() == group->Stopped && refresh.count() != 0) {
        group->clear();
        for (int i = 0; i < refresh.count(); i++) {
            Cellule *val = refresh.at(i);
            val->refresh();
            QPropertyAnimation *a = new QPropertyAnimation(val, "scale");
            a->setDuration(duration);
            a->setEasingCurve(QEasingCurve::Linear);
            a->setStartValue(val->scale());
            a->setKeyValueAt(0.5, 1.2);
            a->setEndValue(val->scale());
            group->addAnimation(a);
            a = new QPropertyAnimation(val, "pos");
            a->setDuration(duration);
            a->setEasingCurve(QEasingCurve::Linear);
            a->setStartValue(val->pos());
            qreal d = val->boundingRect().width();
            a->setKeyValueAt(0.5, val->pos() - QPoint(d, d) * 0.1);
            a->setEndValue(val->pos());
            group->addAnimation(a);
        }
        group->start();
    } else {
        if (group->state() != group->Stopped) {
            group->setCurrentTime(group->totalDuration());
            group->stop();
        }
        group->clear();
        for (int i = 0; i < refresh.count(); i++)
            refresh.at(i)->refresh();
    }
    for (int i = 0; i < news.count(); i++)
        news.at(i)->show();
    qDeleteAll(deletes);
    clear();
}

void Action::add(QGraphicsWidget *val, QPointF to)
{
    QPropertyAnimation *a = new QPropertyAnimation(val, "pos");
    a->setDuration(duration);
    a->setEasingCurve(QEasingCurve::OutQuad);
    a->setStartValue(val->pos());
    a->setEndValue(to);
    group->addAnimation(a);
}

void Action::New(QGraphicsWidget *val)
{
    if (group->state() != group->Running)
        return;
    if (deletes.indexOf(val) != -1)
        return;
    val->hide();
    news.append(val);
}

void Action::Delete(QGraphicsWidget *val)
{
    if (deletes.indexOf(val) == -1)
        deletes.append(val);
}

void Action::Refresh(Cellule *val)
{
    if (refresh.indexOf(val) == -1)
        refresh.append(val);
}




void Action::purge(QGraphicsWidget *val)
{
    for (int i = 0; i < group->animationCount(); i++)
        if (((QPropertyAnimation *)group->animationAt(i))->targetObject() == val)
            group->removeAnimation(group->animationAt(i));
}

void Action::clear(void)
{
    news.clear();
    deletes.clear();
    refresh.clear();
}
