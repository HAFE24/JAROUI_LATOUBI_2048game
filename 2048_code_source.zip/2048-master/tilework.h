#ifndef TILEWORK_H
#define TILEWORK_H

#include <QColor>
#include <QFont>

class Tilework
{
public:
	enum DataType {Background = 0, Foreground = 1, FontSize = 2};

    static QColor foreground(const unsigned int val);
    static QColor background(const unsigned int val);
    static QFont font(const unsigned int val);

private:
	static unsigned long data(const unsigned long index, const DataType type);
    static unsigned long toIndex(const unsigned long val);

	static const unsigned long d[13][3];
};

#endif // TILEWORK_H
